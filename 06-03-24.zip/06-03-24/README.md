# Coding Boot Camp
### June 2024 Cohort

<hr>

:fire: Welcome to your `Coding Bootcamp` Class Repository :fire: 

This is your one-stop-shop for all things `Bootcamp` related.

Below your will find an growing listing of our **Course Sections** as we moved through them.

If you have questions about `Course Guidelines` such as `Student Support Listing`, `Code Of Student Conduct`, etc please **[Click Here](course-content/00-admin-resources/README.md)**.

<hr>

## Course Content
[Back to Top](#coding-boot-camp)

| # | Section Name | Description |
|:--| :--  | :--  |
|01| [HTML Git CSS](course-content/01-html-git-css/README.md)| HTML Tags, Box Model, Floats, Classes, IDs, Positioning, Dev Tools | 




<hr>
<hr>
<hr>











