## Attendance
[Back to Course Guidelines](README.md)

You can miss **no more** than a total of **4 classes**.


## Late Policy

3 Lates adds up to a single absence. 

You can be late to **no more** than a total **12 classes** given that you have **0** absences. 

It is recomended that sudents arrive 5 minutes prior to the start of class. Class starts at 10am. 

Students who are late more then 5 minutes will be marked as late. 