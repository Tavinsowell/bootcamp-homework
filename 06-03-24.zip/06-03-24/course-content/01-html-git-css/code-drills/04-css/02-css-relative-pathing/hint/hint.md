* For relative file paths, `..` means to step into the parent directory and `.` refers to the current directory
  * For example, `../otherDirectoryName/` will step up a directory from the current directory and enter a sibling directory named `otherDirectoryName`
  