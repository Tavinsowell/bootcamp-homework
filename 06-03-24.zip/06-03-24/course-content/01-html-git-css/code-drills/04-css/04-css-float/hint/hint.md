* When selecting classes and ids from the HTML, you can use `.`s to select classes and `#` to select ids
    * For example, `.testClass` selects all the elements with a class of `testClass`
